---
title: Arrow left circle fill
layout: icon
categories:
  - Shape Arrows
tags:
  - arrow
  - circle
---
