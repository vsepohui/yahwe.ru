---
title: Clipboard data
categories:
  - Real world
tags:
  - copy
  - paste
  - data
  - analytics
  - graph
  - chart
---
